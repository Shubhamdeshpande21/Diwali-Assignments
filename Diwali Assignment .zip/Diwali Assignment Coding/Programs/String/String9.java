import java.util.Scanner;
class String9{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String s=sc.next();
		int num=Integer.parseInt(s);
		System.out.println("int value="+num);
	}	
}
/*
567
int value=567	
*/